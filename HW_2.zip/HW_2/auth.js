document.addEventListener('DOMContentLoaded', () => {
 
    
    let callBackButton = document.querySelector('#button-add-cat');
   
  
    let modal1 = document.querySelector('.modal');
   
  
    let closeButton = modal1.querySelector('.modal__close-button');
    
   
   
    callBackButton.onclick = function () {
        if (document.cookie.length == 0){
        
        modal1.classList.add('modal_active');
      }
    }

    
    closeButton.onclick = function () {
      modal1.classList.remove('modal_active');
    }
  });
  

 //let authorizationButton = document.querySelector('.form_auth_button');
 // authorizationButton.onclick = function createCookie (){
    //document.cookie = `user1=Петя;secure;samesite=lax;`
   // console.log(document.cookie);
    
 // }

  