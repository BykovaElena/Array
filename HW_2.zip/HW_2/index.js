
const rootPopup = document.querySelector('.root-popup');
const popupCats = document.querySelector('.popup-type-cats-info');
const popupAddCats = document.querySelector('.popup-type-cats-add');
const popupCatImage = popupCats.querySelector('.popup-photo');
const popupCatText = popupCats.querySelector('.popup-text');
const popupCatDescription = popupCats.querySelector('.popup-description');
const popupCatAge = popupCats.querySelector('.popup-age');
const popupEditCats =document.querySelector('.popup-type-cats-edit');
const closePopupCats = document.querySelector('.popup-close');

const formAdd = popupAddCats.querySelector('.popup-form');
const formEdit = popupEditCats.querySelector('.popup-form')



const inputId = formAdd.querySelector('#id');
const inputName = formAdd.querySelector('#name');
const inputImg = formAdd.querySelector('#img_link');
const inputDesc = formAdd.querySelector('#description');

const catImages = document.querySelectorAll('.cat-photo');


const cardTemplate = document.querySelector('#card-template');
const cardListContainer = document.querySelector('.cats-list');

const buttonReloadData = document.querySelector ('.reload-data');
const buttonAddCat = document.querySelector ('#button-add-cat');






function formSerialize(form){
const result = {}
const inputs = form.querySelectorAll('input');
inputs.forEach(input => {
    result[input.name] = input.value;
})
return result
}



function openPopup (popup){
    //if (document.cookie.length == 0){
      
//}else {
    popup.classList.add ('popup-opened');    
}
//}
function handleClickCloseBtn(event){

    if(event.target.classList.contains('popup-close')){
        closePopup ()  
    }
}



function closePopup (){

    
    const popupActive = document.querySelector('.popup-opened')
   if (popupActive) { 
       popupActive.classList.remove ('popup-opened');
 }


}




   



   function createCardCat (dataCat){
     const newCardElement =  cardTemplate.content.querySelector('.cat-list-item-cat').cloneNode(true);
      
       
     const cardImage = newCardElement.querySelector('.cat-photo');
     const cardName = newCardElement.querySelector('.cat-name');
    const catRate = newCardElement.querySelector('.rate');
    const cardButtonDelete = newCardElement.querySelector('.cat-delete');
    const cardButtonEdit = newCardElement.querySelector('.cat-edit');

     
     
     cardImage.src = dataCat.img_link;
     cardName.textContent = dataCat.name;
     cardName.dataset.id = dataCat.id;
     catRate.textContent = dataCat.rate;

     
     

     function handleClickCatImage(){
        
        popupCatImage.src = dataCat.img_link;
        popupCatText.textContent = dataCat.name;

        popupCatAge.textContent = dataCat.age;
        
        if (+dataCat.age >=11&& +dataCat.age <=20){
            popupCatAge.textContent +=' лет' 
        }else if (+dataCat.age ==1) {
            popupCatAge.textContent +=' год'
        }else if (+dataCat.age >=2 && +dataCat.age<=4){
            popupCatAge.textContent +=' года'
        }else if(+dataCat.age >=5 && +dataCat.age<=9){
            popupCatAge.textContent +=' лет'
        }

        popupCatDescription.textContent = dataCat.description;

        openPopup(popupCats) 
    }

    function handleClickCatEdit() {
        const inputs = formEdit.querySelectorAll('input');
        inputs.forEach(input => {
            input.value = dataCat[input.name];
        });
        
        openPopup(popupEditCats)

    }
    function getLocalStorageData (key){
        return JSON.parse(localStorage.getItem(key));
        }

        function setLocalStorageData (key, data){
             localStorage.setItem(key, JSON.stringify(data));
            }

            
     
    function handleClickButtonDelete(){
        fetch(`https://sb-cats.herokuapp.com/api/delete/${dataCat.id}`,{
            method: 'DELETE'
        })
        .then((response)=>{
            if (response.ok){
                return response.json();
            }
     return Promise.reject(response)
        })
        .then((data)=>{
            if(data.message === 'ok') {
                
                newCardElement.remove();
                const oldData = getLocalStorageData('cats');
                const newData = oldData.filter (item => item.id !== dataCat.id);
                setLocalStorageData('cats', newData);

            }
        })       
    }
    cardButtonEdit.addEventListener('click', handleClickCatEdit)
    cardButtonDelete.addEventListener('click', handleClickButtonDelete)
     cardImage.addEventListener('click', handleClickCatImage)
return newCardElement;

   }

   function cardAddToContainer(elementNode, container){
       container.append(elementNode)

   }

   

   function getCats(){
    return fetch('https://sb-cats.herokuapp.com/api/show')
    .then((response)=>{
        if (response.ok){
            return response.json();
        }
 return Promise.reject(response)
    })
    .then(({data})=>{
    localStorage.setItem('cats', JSON.stringify(data))
     data.forEach(dataCat => cardAddToContainer (createCardCat(dataCat),cardListContainer))
     return data;
    })
    .catch(err => {
 
    })
   }
   

   function handleClickButtonAdd() {
    openPopup(popupAddCats) 
   }


formEdit.addEventListener ('submit',(event)=>{
    event.preventDefault();
const bodyJSON = formSerialize(formEdit)

fetch(`https://sb-cats.herokuapp.com/api/update/${bodyJSON.id}`,{
    method: 'PUT',
    body: JSON.stringify (bodyJSON),
    headers: {
"Content-type":'application/json'
    }
   })
   
   .then((response)=>{
       if (response.ok){
           return response.json();
       }
return Promise.reject(response)
   })
   .then((data)=>{
if(data.message === 'ok') {
reloadData();
closePopup();

}
   
   
   })
   .catch(err => {

   })
})


   
   formAdd.addEventListener ('submit',(event)=>{
       event.preventDefault();
const bodyJSON = formSerialize(formAdd)


        fetch('https://sb-cats.herokuapp.com/api/add',{
        method: 'POST',
        body: JSON.stringify (bodyJSON),
        headers: {
"Content-type":'application/json'
        }
       })
       
       .then((response)=>{
           if (response.ok){
               return response.json();
           }
    return Promise.reject(response)
       })
       .then((data)=>{
if(data.message === 'ok') {
    reloadData();
    closePopup();

}
       
       })
       .catch(err => {
    
       })
   })

function reloadData(){
    localStorage.clear();
    cardListContainer.innerHTML = "";
    getCats()
}

   buttonAddCat.addEventListener('click', handleClickButtonAdd)
   

   rootPopup.addEventListener('click', handleClickCloseBtn);
buttonReloadData.addEventListener('click', reloadData);






getCats()


